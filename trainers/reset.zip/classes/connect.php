<?php
/*
this file is for the database connection in this case:
The Database Name is easyforum
The login is root
The password is empty
You can change to macth your phpMyadmin configuration
*/
try {
	$bdd = new PDO("mysql:host=localhost;dbname=digititan_forum","root","");
} catch (Exception $e) {
	die("Error : ".$e->getMessage());
}

?>