<!--
this is a simple menu for the guest users
-->
<!--HEADER BEGIN-->
<header id="index-header" class="WhiteHeader" style="top:0px;">
		<div id="inside-header">
			<a class="logo"><img src="../images/logo.png" height="50px"/></a>
			<nav class="nav">
				<li><a href="../">HOME</a></li>
				<li><a href="../guest/">GUEST</a></li>
				<li><a href="../guest/categories-list-guest.php">CATEGORIES</a></li>
				<li><a href="../guest/rooms-guest.php">ROOMS</a></li>
				<!--<li><a href="../guest/about.php">ABOUT</a></li>	-->		
			</nav>
			<div id="index-menu-show" title="Show menu"></div>
			
			<nav class="responsive-nav WhiteHeader">
					<li><a href="../">HOME</a></li>
					<li><a href="../guest/">GUEST</a></li>
					<li><a href="../guest/categories-list-guest.php">CATEGORIES</a></li>
					<li><a href="../guest/rooms-guest.php">ROOMS</a></li>
					<!--<li><a href="../guest/about.php">ABOUT</a></li>-->
			</nav>
		</div>
	</header>
<!--HEADER END-->	