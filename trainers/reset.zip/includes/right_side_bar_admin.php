<?php 
//This file be included on some pages to display the website stats for admins

?>
<div id="right-container-admin">
	<div class="side-title-admin menu-gradient">	<div class="small-top-bar-icones notfication-what-icon" style="background-position:-257px -1px; margin-right:5px;"></div>
	Website Stats
	</div>
	<div class="stats-row">
		<span class="stats-row-left">Users</span>
		<span class="stats-row-right" id="UsersNumber">0</span>
	</div>
	<div class="stats-row">
		<span class="stats-row-left">Connected users</span>
		<span class="stats-row-right"  id="ConnectedUsersNumber">0</span>
	</div>
	<div class="stats-row">
		<span class="stats-row-left">Categories</span>
		<span class="stats-row-right" id="CategoriesNumber">0</span>
	</div>
	<div class="stats-row">
		<span class="stats-row-left">Rooms</span>
		<span class="stats-row-right" id="RoomsNumber">0</span>
	</div>
	<div class="stats-row">
		<span class="stats-row-left">Subjects</span>
		<span class="stats-row-right" id="SubjectsNumber">0</span>
	</div>
	<div class="stats-row">
		<span class="stats-row-left">Comments</span>
		<span class="stats-row-right" id="CommentsNumber">0</span>
	</div>
</div>	

