<!--
Side bar that will be displayed on the guest space
You can add your Publicity here (Google Adsense or other)
-->
<div id="publicity-right">
	<div class="side-title">	
		<div class="small-top-bar-icones notfication-what-icon" style="background-position:-287px 1px; margin-right:5px;"></div> 
		Sponsored By</div>
		<div id="advetising-div">
			<br/>
			280 x 250
			advertising space
		</div>
</div>